Esses são materiais que foram usados em aula, há um bom tempo. Assim, considere que:

- O material não foi revisado ou limpo! Por ser um material de aula, pode haver "células soltas", e coisas aparentemente desconexas pra quem não assistiu à aula. Lembre-se que nossas aulas são live-coding, então é natural que haja certa não-linearidade. Espero que isso não torne os notebooks confusos demais, e que eles ainda possam ser úteis;

- Por ser um material antigo, pode ser que o conteúdo nele não seja 100% aderente à ementa atual. Então, tome cuidado! O planejamento do módulo é o documento oficial que deve ser seguido. Neste material, pode haver conteúdo a mais ou a menos com relação ao planejamento atual. Saiba filtrar bem!

Feitos estes adendos, espero que o material seja útil! 
E lembre-se que este material existe apenas para lhe auxiliar. Não há qualquer obrigatoriedade de segui-lo à risca.

Qualquer dúvida, só chamar!

Abraços,
André.